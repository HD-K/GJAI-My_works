import csv

csv_file_path = './csvfile.csv'


def read_csv(): 
    with open(csv_file_path, 'r', encoding='UTF-8-sig') as csv_data:
        storage_data = csv.reader(csv_data)
        return storage_data

def read_csv_dict():
    data_dict = []
    with open(csv_file_path, 'r', encoding='UTF-8-sig') as csv_data:
        storage_data_dict = csv.DictReader(csv_data)
        
        for row in storage_data_dict:
            data_dict.append({'ID' : row['ID'], 'PW' : row['PW']})
        
        return data_dict

def write_csv(id, pw):
    data = read_csv_dict()
    with open(csv_file_path, 'w', encoding='UTF-8-sig') as csv_data:
        fieldnames = ['ID', 'PW']
        writer = csv.DictWriter(csv_data, fieldnames=fieldnames)
        writer.writeheader()
        for row in data:
            writer.writerow({'ID' : row['ID'], 'PW' : row['PW']})
        writer.writerow({'ID' : id, 'PW' : pw})

id = input("ID를 입력하세요. : ")
pw = input("PW를 입력하세요. : ")

write_csv(id, pw)
data_dict = read_csv_dict()


print(data_dict)



